import React, { Component } from 'react';
import { View, Button, Alert } from 'react-native';

export default class App extends Component {
  render(){
    return(
      <View>
      <View
      style ={{width: 300, height: 150, marginTop: 20, marginLeft: 45}}>
      <Button
        title="Stephen Hawking"
        color="red"
        onPress={() => Alert.alert('Discovered A Major Part Of Black Holes.')} />
        </View>

        <View
      style ={{width: 300, height: 150, marginTop: 20, marginLeft: 45}}>
      <Button
        title="George Washington"
        color="green"
        onPress={() => Alert.alert('First US President.')} />
        </View>

        <View
      style ={{width: 300, height: 150, marginTop: 20, marginLeft: 45}}>
      <Button
        title="Rosa Parks"
        color="blue"
        onPress={() => Alert.alert('Stood For Civil Rights.')} />
        </View>

        <View
      style ={{width: 300, height: 150, marginTop:20, marginLeft: 45}}>
      <Button
        title="Swami Vivekananda"
        color="orange"
        onPress={() => Alert.alert('Maker Of Modern India.')} />
        </View>
        </View>
    )
  }
}